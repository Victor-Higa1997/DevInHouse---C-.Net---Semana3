﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Administration.Core
{
    public class ContaBancaria
    {
        protected int ContaNumero;
        protected int ContaDigito;
        protected string NomeTitular;
        protected string Agencia;

       
    }
}
